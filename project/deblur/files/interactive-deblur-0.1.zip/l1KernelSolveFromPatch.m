%--------------------------------------------------------------------------
% Son Hua, NUS
% 2010-06-15
%--------------------------------------------------------------------------

function K = l1KernelSolveFromPatch(P, N, varargin)
% Least square optimization with L1-norm regularization to solve kernel K
% from a given blur patch containing the kernel shape.
%
% L1-norm is minimized by L1-LS package.
% Minimize \| D \conv P -  D \conv K \|_2 + \lambda \| K \|_1
%
% P      : the input blur patch ensembling the kernel. 
% lambda : sparseness strength
% D      : the derivative filter (Laplacian by default)

D = fspecial('laplacian');
lambda = 0.1;
if nargin >= 3
    lambda = varargin{1};
end
if nargin >= 4
    D = varargin{2};
    lambda = varargin{1};
end

% this is a convex optimization. The solution is indepedent of
% initialization value. 
K = zeros(size(P));

%B = imfilter(P, D, 'conv', 'replicate');
B = roifilt2(D, P, N); % filter with a ROI

% remove two pixels from the border to avoid derivative artifacts
borderN = bwmorph(N, 'remove');
B(borderN) = 0;
N(borderN) = 0;
borderN = bwmorph(N, 'remove');
B(borderN) = 0;

[dh dw] = size(D);
[kh kw] = size(K);
% only support square kernel

A = MatrixDerivativeKernel(D, kh);
At = A'; % implicitly call ctranspose function
b = reshape(B, [kh*kw 1]); % column vector
                           %k = zeros([1 kh*kw]);

targetGap = 0.001;

disp 'Least square with L1-norm solving...';
[k, status] = l1_ls_nonneg(A, At, dh*dw, kh*kw, b, lambda, targetGap);

K = reshape(k, [kh kw]);
K = K / sum(K(:));

