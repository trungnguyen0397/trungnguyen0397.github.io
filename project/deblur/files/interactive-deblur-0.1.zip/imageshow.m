function I = imageshow(I, gamma)
% gamma correct the linear signal before display
    imshow(I .^ (1 / gamma));
end
