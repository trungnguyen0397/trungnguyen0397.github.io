function I = imageread(file, gamma)
% image I/O with gamma correction
    I = im2double(imread(file));
    I = I .^ gamma;
end
