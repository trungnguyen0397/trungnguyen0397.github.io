%--------------------------------------------------------------------------
% Son Hua, NUS
% 2010-06-08
%--------------------------------------------------------------------------

function [I, rad_left, rad_right, rad_top, rad_bottom] = expandImagePow2(I, K, val)
% Expand image to a power-of-two size for FFT computation. This is also to
% avoid MATLAB to automatically pad the image with zero, which causes
% ringing artifacts in deconvolution. The image must be pad with extend
% boundary values.

[h, w, d] = size(I);
[kh, kw] = size(K);
sizePow2H = 2^nextpow2(h + kh);
sizePow2W = 2^nextpow2(w + kw);
rad_top = floor((sizePow2H - h) * 0.5);
rad_left = floor((sizePow2W - w) * 0.5);
rad_bottom = sizePow2H - h - rad_top;
rad_right = sizePow2W - w - rad_left;
% treat boundary condition
if nargin < 3 % default expand boundary
    I = I([ones(1, rad_top), 1:h, h*ones(1, rad_bottom)], [ones(1, rad_left), 1:w, w*ones(1, rad_right)], :);
else
    oldI = I;
    I = zeros(sizePow2H, sizePow2W); 
    I(:) = val;
    I(rad_top + 1 : h + rad_top, rad_left + 1 : w + rad_left) = oldI;
end

