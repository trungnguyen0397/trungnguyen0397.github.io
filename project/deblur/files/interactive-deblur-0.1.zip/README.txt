-------------------------------------------------
Interactive Motion Deblurring Using Light Streaks
-------------------------------------------------

Binh-Son Hua, huabinhs@comp.nus.edu.sg. 

* 2011-09-04: Version 0.1 released. 

0. License
----------
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by	
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

1. Quick start
--------------
To run the 'yasaka' example with default parameters, execute the
following command in MATLAB: 

> interactiveDeblur('yasaka')

2. Folder and files
-------------------
The code is written in MATLAB. It is tested in MATLAB version R2009b
(7.9.0.529) 32-bit.  
 
* Main files
  + images : folder to store input and output image files. 
    It contains an example which is ready for you to try. 
  + l1-ls  : L1 optimization package by Koh, Kim, and Boyd. 
    The original package can be downloaded at
    http://www.stanford.edu/~boyd/l1_ls/. 
  + interactiveDeblur.m : main function.
  + l1KernelSolveFromPatch.m  : kernel extraction function. 
  + l2ImageFFT.m : image deblurring function. 

* Utility files
  - @MatrixDerivativeKernel : MatrixDerivativeKernel class. 
  + expandImagePow2.m : utility function to expand the image dimension
    to the nearest power of two.  
  + imageread.m, imageshow.m, imagewrite.m : image utility function
    that includes gamma correction.   

3. Workflow
-----------
Basically, when calling interactiveDeblur function with a new image,
the program will guide you through the following steps:  

a. The program displays the image and asks user to select a masking
region that contains an appropriate light streak.  

A polygon drawing tool is selected by default and ready for mask
selection. For accurate selection, you can click on the magnifying
icon and zoom in. Click on the magnifying icon again to unselect it
and return to the default polygon tool. Select the region you want.  

When you are finished defining the region, double click at the last
vertex of the polygon. The program will take your masked region and
proceed to the next step.  

b. The blur kernel is extracted from the patch and the image is
deblurring by solving the optimization problems as described in the
paper.  

4. Additional parameters
------------------------
The interactiveDeblur function can be called with additional
parameters: 

> interactiveDeblur('yasaka', 
    <mask index>, <overwrite current mask>, <lambda>) 

By default, calling 

> interactiveDeblur('yasaka') 

is equivalent to

> interactiveDeblur('yasaka', 1, 0, 0.1)

The index of the mask by default is 1. Sometimes, you may want to try
different regions in the image and compare their deblurred
results. You can ask the program to save the mask with a new index,
say 2: 

> interactiveDeblur('yasaka', 2); 

When <overwrite current mask> is set to 0, the function will first
check if the mask is available. If the mask exists, the function
proceeds to extract kernel and deblur. Otherwise, it will ask for user
interaction to provide a mask.  

When <overwrite current mask> is set to 1, the function will always
overwrite the mask even it exists, and ask for user interaction.  

The <lambda> parameter controls the strength of the sparsity
constraint on the kernel. You may want to lower <lambda> if the kernel
appears to be different from the light streak you selected.  

Sometimes you may need to perform gamma correction for the input image
(optional). This can be done by setting the paramater opts.gamma in
interactiveDeblur function.  

5. Contact
----------
If you have any problems with the code, please feel free to drop me an
email at huabinhs@comp.nus.edu.sg. I will try my best to assist you.  

