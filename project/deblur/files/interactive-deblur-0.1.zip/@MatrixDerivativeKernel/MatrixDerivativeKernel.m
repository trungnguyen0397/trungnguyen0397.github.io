%--------------------------------------------------------------------------
% Son Hua, NUS
% 2010-06-15
%--------------------------------------------------------------------------

classdef MatrixDerivativeKernel < handle
% Special matrix representating an image that provides fast convolution
% operation via the mtimes operator *
% 
% This class is used for kernel estimation with a highlighted blurred patch
% only.
% Kernel estimation equation: D \corr D \conv K = D \corr B
% where D is the derivative filter

    properties
        D = [];
        sizeK = 0;
        transpose = 0;
    end
    
    methods
        function obj = MatrixDerivativeKernel(D, sizeK)
            obj.D = D;            
            obj.sizeK = sizeK;
        end
        
        function r = ctranspose(obj)
            r = MatrixDerivativeKernel(obj.D, obj.sizeK);
            r.transpose = xor(obj.transpose, 1);
        end
        
        function r = mtimes(M, k)
            % M is a MatrixDerivativeKernel object

            % perform convolution between D and K
            if M.transpose == 0
                kh = floor(sqrt(size(k, 1)));
                kw = kh;
                kernel = reshape(k, [kh kw]);    
                out = imfilter(kernel, M.D, 'same', 'conv', 'replicate');                
                r = reshape(out, [kh*kw 1]);
            else
                % the input for A' has the same size as K
                kh = M.sizeK;
                kw = kh;
                kernel = reshape(k, [kh kw]);
                
                out = imfilter(kernel, M.D, 'same', 'corr', 'replicate');
                
                r = reshape(out, [kh*kw 1]);
            end
        end
    end
end

