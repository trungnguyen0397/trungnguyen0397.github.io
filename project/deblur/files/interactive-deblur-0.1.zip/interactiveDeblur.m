%--------------------------------------------------------------------------
% Son Hua, NUS
% 2011-04-09
%--------------------------------------------------------------------------

function interactiveDeblur(name, varargin)
% This is the main function that performs image deblurring using light
% streaks. 
%
% Parameters:
% - name: name of the input jpeg file. 
%
% Optional parameters:
% - index: index of the mask region selected by user. Default 1.  
% - overwrite mask: set to 1 to always overwrite mask; set to 0 to use
%   existing mask if available. Default 0. 
% - lambda: sparsity strength. Default 0.1. 
%
% Example: 
% >  interactiveDeblur('yasaka')
% >  interactiveDeblur('yasaka', 2, 0, 0.01)
    
addpath('./l1-ls'); % a modified version of l1_ls_nonneg for displaying
                    % intermediate kernel result.

opts.gamma = 1.0; % no gamma correction               
%opts.gamma = 2.2; 

opts.inputFileTemplate = 'images/%s.jpg';
opts.inputMaskTemplate = 'images/%s_mask_%02d.pbm';
opts.outputFileTemplate = 'images/%s_deblurred_%02d.jpg';
opts.inputFile = sprintf(opts.inputFileTemplate, name);

% default parameters
lambda = 0.1;
index = 1;
opts.forceNewMask = false;

% parse input parameters
if nargin >= 2
    index = varargin{1};
end
if nargin >= 3
    opts.forceNewMask = varargin{2};
end
if nargin >= 4
    lambda = varargin{3};        
end
  
opts.inputMask = sprintf(opts.inputMaskTemplate, name, index);
opts.outputFile = sprintf(opts.outputFileTemplate, name, index);

colorB = imageread(opts.inputFile, opts.gamma);
depth = size(colorB, 3);
B = colorB;

% perform interactive crop
if ~exist(opts.inputMask) || (isfield(opts, 'forceNewMask') && opts.forceNewMask == true)
    % get a region of interest. M is the binary mask.
    M = roipoly(B .^ (1 / opts.gamma));
    % M should be saved as 1-bit uncompressed format (PBM).
    imwrite(M, opts.inputMask);
else
    % M is an logical 0/1 mask as M is saved in 1-bit uncompressed format.
    M = imread(opts.inputMask);
end

% find its bounding box
stats = regionprops(M, 'BoundingBox');
bb = stats.BoundingBox;
% copy ROI from the blur image to the patch
xl = bb(1); 
yl = bb(2);
xw = bb(3);
yw = bb(4);
psize = max(yw, xw);
if mod(psize, 2) == 0
    psize = psize + 1
end
yr = min(yl + psize - 1, size(M, 1));
xr = min(xl + psize - 1, size(M, 2));

P = zeros(psize); % make a square patch
N = logical(zeros(psize));
if depth > 1
    B = rgb2gray(B);
end    
N(1 : (yr - yl + 1), 1 : (xr - xl + 1)) = M(yl : yr, xl : xr); % mask of patch P 
                                                               
fprintf('Kernel size: %d %d\n', size(N, 1), size(N, 2));

% copy user selected region to patch P
P(N) = B(M);

[h, w] = size(P);
if h ~= w 
    error('Only allow square patch.');
end

figure; % create a figure and display intermediate results of the
        % optimization 
tic;
K = l1KernelSolveFromPatch(P, N, lambda);
kernelTime = toc;

disp 'Latent image deconvolution:'
tic;
colorI = deblur(colorB, K);
imageTime = toc;

fprintf('Kernel time: %f\n', kernelTime);
fprintf('Image time: %f\n', imageTime);
fprintf('Total running time: %f\n', kernelTime + imageTime);

% save deblurred image
imagewrite(colorI, opts.outputFile, opts.gamma);

% display results
figColorB = figure;
imageshow(colorB, opts.gamma); title('Blurred image');
figColorI = figure;
imageshow(colorI, opts.gamma); title('Deblurred image');

function colorI = deblur(colorB, K)
for d = 1 : size(colorB, 3)
    B = colorB(:, :, d);
    
    % normalize inputs
    E = sum(B(:));
    B = B / E;

    % solve using L2-norm regularization with FFT.
    %% original deblurring for results in the paper
    I = l2ImageFFT(B, K, [0.1 4 0], 0.1, 0);
    
    I = I / (sum(I(:))) * E;
    
    colorI(:, :, d) = I;
end

