function I = imagewrite(I, file, gamma)
% image I/O with gamma correction
    I = I .^ (1 / gamma);
    imwrite(I, file);
end
