%--------------------------------------------------------------------------
% Son Hua, NUS
% 2010-05-26
%--------------------------------------------------------------------------

function I = l2ImageFFT(B, K, omega, lambda, epsilon)
% This function implements a closed-form solution to L2 regularization to
% estimate latent image I from input blurred B and kernel K.

[h, w] = size(B); 
    
[B, rad_left, rad_right, rad_top, rad_bottom] = expandImagePow2(B, K);    
    
if nargin < 5
    epsilon = 0;
end
if nargin < 4
    lambda = 0.5;
end
if nargin < 3
    omega0 = 0.1;
    omega1 = 4.0;
    omega2 = 1.0;        
else
    omega0 = omega(1);
    omega1 = omega(2);
    omega2 = omega(3);
end
    
dxf = [1, -1];
dyf = [1; -1];
dxxf = [1, -2, 1];
dyyf = [1; -2; 1];
dxyf = [2, -1; -1, 0];
sizeImg = size(B);
    
fB = fft2(B);    
fK = psf2otf(K, sizeImg);
    
fDx = psf2otf(dxf, sizeImg);
fDy = psf2otf(dyf, sizeImg);
fDxx = psf2otf(dxxf, sizeImg);
fDyy = psf2otf(dyyf, sizeImg);
fDxy = psf2otf(dxyf, sizeImg);


fD = omega0 * ones(sizeImg) + ...
     omega1 * (conj(fDx) .* fDx + conj(fDy) .* fDy) + ...
     omega2 * (conj(fDxx) .* fDxx + conj(fDyy) .* fDyy + conj(fDxy) .* fDxy);
fI = (conj(fK) .* fB .* fD) ./ (epsilon + conj(fK) .* fK .* fD + ...
                                lambda * (conj(fDx) .* fDx + conj(fDy) .* fDy));
    
I = real(ifft2(fI));
I = I(rad_top + 1 : h + rad_top, rad_left + 1 : w + rad_left);

